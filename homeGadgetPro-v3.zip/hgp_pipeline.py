"""
╔══════════════════════════════════════════════════════════════════╗
║         HomeGadgetPro — Automated Product Pipeline              ║
║                                                                  ║
║  What this script does:                                          ║
║  1. Fetches top products per category from Rainforest API        ║
║  2. Sends each product to Claude AI to write:                    ║
║     - Verdict paragraph                                          ║
║     - Pros & cons                                                ║
║     - Best for tags                                              ║
║     - HomeGadgetPro score out of 100                             ║
║  3. Saves everything to products.json                            ║
║  4. Generates a JavaScript file ready to drop into your site     ║
║                                                                  ║
║  HOW TO RUN:                                                      ║
║  ─────────────────────────────────────────────────────────────   ║
║  1. Install Python 3.9+ if you don't have it:                    ║
║     https://www.python.org/downloads/                            ║
║                                                                  ║
║  2. Install required packages. Open Terminal and run:            ║
║     pip install anthropic requests                               ║
║                                                                  ║
║  3. Fill in your API keys below (lines 60-70)                    ║
║                                                                  ║
║  4. Run the script:                                              ║
║     python hgp_pipeline.py                                       ║
║                                                                  ║
║  5. It will create two files:                                    ║
║     - products.json  (raw data, good for backups)                ║
║     - products.js    (drop this into your website folder)        ║
║                                                                  ║
║  HOW OFTEN TO RUN:                                               ║
║  Run it once a week to keep prices & products fresh.             ║
║  On a Mac you can automate this with cron (ask Claude how).      ║
╚══════════════════════════════════════════════════════════════════╝
"""

import anthropic
import requests
import json
import time
import re
from datetime import datetime

# ══════════════════════════════════════════════════════════════════
#  🔑 YOUR API KEYS — fill these in before running
# ══════════════════════════════════════════════════════════════════

RAINFOREST_API_KEY = "YOUR_RAINFOREST_API_KEY"
# Get yours at: https://www.rainforestapi.com
# Free trial: 10 requests. Paid from $15/month.

ANTHROPIC_API_KEY  = "YOUR_ANTHROPIC_API_KEY"
# Get yours at: https://console.anthropic.com
# You'll need to add a small amount of credit (~$5 lasts a long time)

AMAZON_AFFILIATE_TAG = "homegadgetpro-21"
# Your Amazon Associates tag — replace when you have it

# ══════════════════════════════════════════════════════════════════
#  ⚙️ SETTINGS — tweak these as needed
# ══════════════════════════════════════════════════════════════════

# How many products to fetch per category (Rainforest API call = 1 request per category)
PRODUCTS_PER_CATEGORY = 6

# Amazon marketplace (amazon.co.uk for UK, amazon.com for US)
AMAZON_DOMAIN = "amazon.co.uk"

# Categories to fetch — keyword : site category name
CATEGORIES = {
    "coffee machines UK":           "coffee",
    "air fryers UK":                "airfryers",
    "robot vacuum cleaner UK":      "hoovers",
    "bluetooth speakers UK":        "speakers",
    "electric kettles UK":          "kettles",
    "blenders UK":                  "blenders",
    "vacuum cleaners cordless UK":  "vacuums",
    "air purifiers UK":             "airpurifiers",
    "toasters UK":                  "toasters",
}

# Category display names and emojis for the site
CATEGORY_META = {
    "coffee":       {"name": "Coffee Machines",  "emoji": "☕"},
    "airfryers":    {"name": "Air Fryers",        "emoji": "🍟"},
    "hoovers":      {"name": "Robot Hoovers",     "emoji": "🤖"},
    "speakers":     {"name": "Speakers",          "emoji": "🔊"},
    "kettles":      {"name": "Kettles",           "emoji": "🫖"},
    "blenders":     {"name": "Blenders",          "emoji": "🥤"},
    "vacuums":      {"name": "Vacuum Cleaners",   "emoji": "🌀"},
    "airpurifiers": {"name": "Air Purifiers",     "emoji": "💨"},
    "toasters":     {"name": "Toasters",          "emoji": "🍞"},
}

# ══════════════════════════════════════════════════════════════════
#  STEP 1 — FETCH PRODUCTS FROM RAINFOREST API
# ══════════════════════════════════════════════════════════════════

def fetch_products_from_rainforest(search_query, max_results=6):
    """
    Searches Amazon via Rainforest API and returns top products.
    Each call uses 1 API credit.
    """
    print(f"  🌧️  Fetching: '{search_query}'...")

    url = "https://api.rainforestapi.com/request"
    params = {
        "api_key":    RAINFOREST_API_KEY,
        "type":       "search",
        "amazon_domain": AMAZON_DOMAIN,
        "search_term": search_query,
        "sort_by":    "featured",
        "exclude_sponsored": "true",
    }

    try:
        response = requests.get(url, params=params, timeout=30)
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as e:
        print(f"  ❌ Rainforest API error: {e}")
        return []

    results = data.get("search_results", [])
    products = []

    for item in results[:max_results]:
        # Skip items without a price or ASIN
        if not item.get("asin") or not item.get("price", {}).get("value"):
            continue

        product = {
            "asin":       item.get("asin", ""),
            "name":       item.get("title", "Unknown Product")[:60],  # trim long titles
            "brand":      item.get("brand", extract_brand(item.get("title", ""))),
            "price":      item.get("price", {}).get("value", 0),
            "old_price":  item.get("price", {}).get("was", {}).get("value") if item.get("price", {}).get("was") else None,
            "rating":     item.get("rating", 0),
            "reviews":    item.get("ratings_total", 0),
            "image":      item.get("image", ""),
            "features":   item.get("feature_bullets", [])[:8],  # first 8 bullet points
            "is_bestseller": item.get("is_best_seller", False),
            "is_new":     item.get("badges", {}).get("is_new_release", False),
            "sponsored":  False,
        }
        products.append(product)
        print(f"     ✓ {product['brand']} — {product['name'][:45]}... £{product['price']}")

    return products


def extract_brand(title):
    """Guess brand from product title (first word usually is brand)."""
    words = title.strip().split()
    return words[0] if words else "Unknown"


# ══════════════════════════════════════════════════════════════════
#  STEP 2 — ENRICH WITH CLAUDE AI
# ══════════════════════════════════════════════════════════════════

def enrich_product_with_claude(product, category_name, client):
    """
    Sends product data to Claude and gets back:
    - Verdict paragraph
    - Pros list
    - Cons list
    - Best for tags
    - Score out of 100
    - Key specs summary
    """
    print(f"  🤖 Enriching: {product['brand']} {product['name'][:40]}...")

    features_text = "\n".join(f"- {f}" for f in product["features"]) if product["features"] else "No features listed"

    prompt = f"""You are writing product content for HomeGadgetPro.co.uk, a UK home appliance comparison site.

Here is a product from Amazon UK:

Category: {category_name}
Brand: {product['brand']}
Name: {product['name']}
Price: £{product['price']}
Rating: {product['rating']}/5 ({product['reviews']:,} reviews)
Amazon features:
{features_text}

Write product content for this item. Respond ONLY with valid JSON, no markdown, no backticks, no explanation. Use this exact structure:

{{
  "verdict": "2-3 sentence expert verdict on this product (honest, specific, helpful)",
  "verdictTag": "Best for: [specific type of person or use case]",
  "pros": ["pro 1", "pro 2", "pro 3", "pro 4"],
  "cons": ["con 1", "con 2", "con 3"],
  "bestFor": ["Best [tag1]", "Best [tag2]"],
  "score": 85,
  "badge": "best or new or sale or null",
  "scoreBreakdown": {{
    "Performance": 85,
    "Value for Money": 80,
    "Ease of Use": 90,
    "Build Quality": 78,
    "Features": 82
  }}
}}

Rules:
- verdict: honest and specific to this product, mention the price if relevant
- pros: real advantages based on the features listed, 4 items
- cons: honest drawbacks, 3 items  
- bestFor: 1-2 short tags like "Best Value", "Best for Families", "Best Budget"
- score: integer 1-100 based on value, quality and reviews (4.5+ rating + good reviews = 80+)
- badge: "best" if score >= 90 and reviews > 1000, "new" if is_new_release, "sale" if old_price exists, otherwise null
- scoreBreakdown: 5 relevant metrics scored 0-100"""

    try:
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = message.content[0].text.strip()

        # Strip any accidental markdown fences
        raw = re.sub(r"^```json\s*", "", raw)
        raw = re.sub(r"```$", "", raw)
        raw = raw.strip()

        enriched = json.loads(raw)
        return enriched

    except json.JSONDecodeError as e:
        print(f"     ⚠️  JSON parse error: {e}. Using defaults.")
        return default_enrichment(product)
    except Exception as e:
        print(f"     ⚠️  Claude error: {e}. Using defaults.")
        return default_enrichment(product)


def default_enrichment(product):
    """Fallback if Claude call fails."""
    return {
        "verdict": f"The {product['brand']} {product['name']} is a well-reviewed option in its category, rated {product['rating']}/5 by {product['reviews']:,} customers on Amazon.",
        "verdictTag": "Best for: Everyday use",
        "pros": ["Highly rated by customers", "Available on Amazon UK", "Free delivery available", "Good value for money"],
        "cons": ["Check reviews for specific use case", "Verify specs before purchasing", "Compare with similar models"],
        "bestFor": ["Popular Choice"],
        "score": min(int(product["rating"] * 18), 95),
        "badge": None,
        "scoreBreakdown": {"Performance": 75, "Value for Money": 75, "Ease of Use": 75, "Build Quality": 75, "Features": 75}
    }


# ══════════════════════════════════════════════════════════════════
#  STEP 3 — BUILD FULL PRODUCT OBJECT
# ══════════════════════════════════════════════════════════════════

# Running product ID counter (starts after existing hardcoded ones)
_next_id = 100

def build_product_object(raw, enriched, category_key, cat_emoji):
    """Combines Rainforest data + Claude enrichment into a full product object."""
    global _next_id
    _next_id += 1

    # Generate simple 12-month mock price history based on current price
    # In a real system this would come from a database of tracked prices
    price = raw["price"]
    price_history = generate_price_history(price, raw.get("old_price"))

    # Build retailers list
    retailers = [
        {
            "name":  "Amazon",
            "logo":  "📦",
            "price": f"£{price:.0f}",
            "asin":  raw["asin"]
        }
    ]

    return {
        "id":         _next_id,
        "asin":       raw["asin"],
        "emoji":      cat_emoji,
        "brand":      raw["brand"],
        "name":       clean_product_name(raw["name"], raw["brand"]),
        "price":      round(price),
        "oldPrice":   round(raw["old_price"]) if raw.get("old_price") else None,
        "rating":     round(raw["rating"], 1),
        "reviews":    raw["reviews"],
        "badge":      enriched.get("badge"),
        "sponsored":  False,
        "image":      raw["image"],
        "bestFor":    enriched.get("bestFor", []),
        "pros":       enriched.get("pros", []),
        "cons":       enriched.get("cons", []),
        "verdict":    enriched.get("verdict", ""),
        "verdictTag": enriched.get("verdictTag", ""),
        "retailers":  retailers,
        "videoId":    "",  # Add YouTube video IDs manually when you have them
        "priceHistory": price_history,
        "scores":     enriched.get("scoreBreakdown", {}),
        "specs": {
            **{f: "" for f in ["Type", "Capacity", "Power", "Weight", "Warranty"]},
            "Score": enriched.get("score", 75)
        },
        "userReviews":    [],
        "lastUpdated":    datetime.now().strftime("%Y-%m-%d"),
    }


def clean_product_name(full_name, brand):
    """Remove brand from start of product name if it's repeated."""
    if full_name.lower().startswith(brand.lower()):
        return full_name[len(brand):].strip(" -–—,")
    return full_name


def generate_price_history(current_price, old_price=None):
    """
    Generate a realistic 12-month price history.
    In future this should be replaced with real tracked data from a database.
    """
    import random
    random.seed(int(current_price * 100))  # deterministic based on price

    history = []
    base = old_price if old_price else current_price * 1.1

    for i in range(12):
        # Simulate gradual price drop with occasional spikes
        variance = random.uniform(-0.08, 0.12)
        month_price = base * (1 - (i * 0.005)) * (1 + variance)
        month_price = max(current_price * 0.85, min(base * 1.15, month_price))
        history.append(round(month_price))

    # Make sure last entry is current price
    history[-1] = round(current_price)
    return history


# ══════════════════════════════════════════════════════════════════
#  STEP 4 — SAVE OUTPUT FILES
# ══════════════════════════════════════════════════════════════════

def save_json(all_products):
    """Save raw product data as products.json (good for backups and debugging)."""
    output = {
        "generated":  datetime.now().isoformat(),
        "total":      sum(len(v) for v in all_products.values()),
        "categories": all_products
    }
    with open("products.json", "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    print(f"\n  💾 Saved products.json ({output['total']} products)")


def save_js(all_products):
    """
    Save as products.js — a JavaScript file you drop into your website folder.
    Your site will automatically use this instead of the hardcoded data.
    """
    js = f"""// ═══════════════════════════════════════════════════════════
// HomeGadgetPro — Auto-generated product database
// Generated: {datetime.now().strftime("%d %B %Y at %H:%M")}
// Total products: {sum(len(v) for v in all_products.values())}
// DO NOT EDIT MANUALLY — re-run hgp_pipeline.py to update
// ═══════════════════════════════════════════════════════════

const ALL_PRODUCTS = {json.dumps(all_products, indent=2, ensure_ascii=False)};

// Flatten all products to one lookup map
const PRODUCT_MAP = {{}};
Object.values(ALL_PRODUCTS).flat().forEach(p => {{ PRODUCT_MAP[p.id] = p; }});

// Get category key for a product id
function getCatForProduct(id) {{
  for (const [cat, prods] of Object.entries(ALL_PRODUCTS)) {{
    if (prods.find(p => p.id === id)) return cat;
  }}
  return null;
}}

const BEST_FOR_DATA = {{}};
Object.entries(ALL_PRODUCTS).forEach(([cat, prods]) => {{
  const tags = [...new Set(prods.flatMap(p => p.bestFor || []))];
  BEST_FOR_DATA[cat] = tags;
}});

const AFFILIATE_TAG = "{AMAZON_AFFILIATE_TAG}";
function getAffiliateLink(asin) {{
  if (!asin) return '#';
  return `https://www.amazon.co.uk/dp/${{asin}}?tag=${{AFFILIATE_TAG}}`;
}}
"""
    with open("products.js", "w", encoding="utf-8") as f:
        f.write(js)
    print(f"  💾 Saved products.js (drop this into your website folder)")


# ══════════════════════════════════════════════════════════════════
#  STEP 5 — PRINT SITE INTEGRATION INSTRUCTIONS
# ══════════════════════════════════════════════════════════════════

def print_instructions(all_products):
    total = sum(len(v) for v in all_products.values())
    print(f"""
╔══════════════════════════════════════════════════════════════════╗
║  ✅ Pipeline complete! {total} products generated                 
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  FILES CREATED:                                                  ║
║  • products.json  — backup / raw data                            ║
║  • products.js    — ready to use in your website                 ║
║                                                                  ║
║  TO USE ON YOUR SITE:                                            ║
║                                                                  ║
║  1. Copy products.js into your website folder                    ║
║     (same folder as landing.html, homespec.html, product.html)   ║
║                                                                  ║
║  2. Add this line to homespec.html and product.html,             ║
║     BEFORE the existing <script> tag:                            ║
║                                                                  ║
║     <script src="products.js"></script>                          ║
║                                                                  ║
║  3. Remove the hardcoded ALL_PRODUCTS data from your HTML        ║
║     files — products.js now handles this automatically.          ║
║                                                                  ║
║  4. Re-run this script any time you want to refresh products:    ║
║     python hgp_pipeline.py                                       ║
║                                                                  ║
║  WHAT TO DO NEXT:                                                ║
║  • Add your real Amazon Associates tag (line 68 above)           ║
║  • Add YouTube video IDs to products manually                    ║
║  • Fill in detailed specs (weight, dimensions etc)               ║
║  • Consider running weekly with a cron job                       ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
""")


# ══════════════════════════════════════════════════════════════════
#  🚀 MAIN — runs everything
# ══════════════════════════════════════════════════════════════════

def run_pipeline():
    print("""
╔══════════════════════════════════════════════════════════════════╗
║        HomeGadgetPro — Product Pipeline Starting                 ║
╚══════════════════════════════════════════════════════════════════╝
""")

    # Check API keys are set
    if RAINFOREST_API_KEY == "YOUR_RAINFOREST_API_KEY":
        print("❌ ERROR: Please set your RAINFOREST_API_KEY on line 60")
        print("   Get one free at: https://www.rainforestapi.com")
        return
    if ANTHROPIC_API_KEY == "YOUR_ANTHROPIC_API_KEY":
        print("❌ ERROR: Please set your ANTHROPIC_API_KEY on line 64")
        print("   Get one at: https://console.anthropic.com")
        return

    # Initialise Claude client
    claude = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    all_products = {}
    product_id_counter = 100

    for search_query, category_key in CATEGORIES.items():
        cat_meta = CATEGORY_META.get(category_key, {"name": category_key, "emoji": "📦"})
        print(f"\n{'═'*60}")
        print(f"📦 Category: {cat_meta['emoji']} {cat_meta['name']}")
        print(f"{'═'*60}")

        # Step 1 — Fetch from Rainforest
        raw_products = fetch_products_from_rainforest(search_query, PRODUCTS_PER_CATEGORY)

        if not raw_products:
            print(f"  ⚠️  No products found for '{search_query}', skipping.")
            continue

        enriched_products = []

        for raw in raw_products:
            # Step 2 — Enrich with Claude
            enriched = enrich_product_with_claude(raw, cat_meta["name"], claude)

            # Step 3 — Build full product object
            product_obj = build_product_object(raw, enriched, category_key, cat_meta["emoji"])
            enriched_products.append(product_obj)

            # Small delay to avoid hitting API rate limits
            time.sleep(0.5)

        all_products[category_key] = enriched_products
        print(f"  ✅ {len(enriched_products)} products ready for {cat_meta['name']}")

        # Pause between categories to be gentle on APIs
        time.sleep(1)

    if not all_products:
        print("\n❌ No products were fetched. Check your API key and internet connection.")
        return

    # Step 4 — Save output files
    print(f"\n{'═'*60}")
    print("💾 Saving output files...")
    print(f"{'═'*60}")
    save_json(all_products)
    save_js(all_products)

    # Step 5 — Print instructions
    print_instructions(all_products)


# ══════════════════════════════════════════════════════════════════
#  TEST MODE — runs without real API keys using mock data
#  Run with: python hgp_pipeline.py --test
# ══════════════════════════════════════════════════════════════════

def run_test_mode():
    """
    Test mode — uses fake data so you can see what the output looks like
    without needing real API keys. Good for checking the setup works.
    """
    print("""
╔══════════════════════════════════════════════════════════════════╗
║        HomeGadgetPro — TEST MODE (no API keys needed)            ║
╚══════════════════════════════════════════════════════════════════╝
""")
    mock_products = {
        "coffee": [
            {
                "id": 101,
                "asin": "B07MXQ73ZW",
                "emoji": "☕",
                "brand": "Sage",
                "name": "Barista Express Impress",
                "price": 699,
                "oldPrice": 749,
                "rating": 4.9,
                "reviews": 1847,
                "badge": "best",
                "sponsored": False,
                "image": "",
                "bestFor": ["Best Premium", "Best for Coffee Lovers"],
                "pros": ["Café-quality espresso", "Integrated precision grinder", "PID temperature control", "Fast 3-second heat-up"],
                "cons": ["Steep learning curve", "Takes up counter space", "Expensive"],
                "verdict": "The Sage Barista Express produces café-quality espresso at home. The integrated grinder and PID control make it the best choice for serious coffee lovers.",
                "verdictTag": "Best for: Coffee enthusiasts who want café quality",
                "retailers": [{"name": "Amazon", "logo": "📦", "price": "£699", "asin": "B07MXQ73ZW"}],
                "videoId": "",
                "priceHistory": [749,739,729,719,699,699,729,719,709,699,679,649],
                "scores": {"Performance": 98, "Value for Money": 80, "Ease of Use": 60, "Build Quality": 95, "Features": 92},
                "specs": {"Type": "Espresso+Grinder", "Pressure": "9 bar", "Capacity": "2L", "Score": 96},
                "userReviews": [],
                "lastUpdated": datetime.now().strftime("%Y-%m-%d"),
            }
        ]
    }
    save_json(mock_products)
    save_js(mock_products)
    print_instructions(mock_products)
    print("✅ Test mode complete — check products.json and products.js")


# ══════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys
    if "--test" in sys.argv:
        run_test_mode()
    else:
        run_pipeline()
